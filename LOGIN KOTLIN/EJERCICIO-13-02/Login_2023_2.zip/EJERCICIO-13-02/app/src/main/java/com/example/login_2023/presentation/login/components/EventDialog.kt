package com.example.login_2023.presentation.login.components

import androidx.annotation.StringRes
import androidx.compose.material.AlertDialog
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun EventDialog(
    modifier: Modifier = Modifier,
    onDismiss: (() -> Unit)? = null,
    @StringRes errorMessage: Int,
) {
    AlertDialog(
        onDismissRequest = { /*TODO*/ },
        title = { Text(text = "") },
        buttons = {

        }
    )
}