package com.example.login_2023.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.login_2023.presentation.login.LoginScreen
import com.example.login_2023.presentation.login.login.LoginViewModel
import com.example.login_2023.presentation.login.screens.HomeScreen
import com.example.login_2023.presentation.login.screens.RegistrationScreen


@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = Destinations.LoginScreen.route
    ) {
        composable("LoginScreen") {
            val viewModel = LoginViewModel()
            LoginScreen(
                navController,
                state = viewModel.state.value,
                onLogin = viewModel::login,
                onDissmissDialog = viewModel::hideErrorDialog,
                onNavigateToRegister = {
                    navController.navigate(Destinations.LoginScreen.route)
                }
            )
        }
        composable("RegistrationScreen") { RegistrationScreen(navController) }
        composable("HomeScreen") { HomeScreen(navController) }
    }
}